using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models.Contractors
{
    public class ContractorArea
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int AreaId { get; set; } // area_id

        // Utenlandsk nøkkel: Hvilken Contractor tilhører dette området
        public int ContractorId { get; set; }
        [ForeignKey("ContractorId")]
        public Contractor Contractor { get; set; }

        [Required]
        [StringLength(255)]
        public string AreaName { get; set; } // area_name

        public string AreaDescription { get; set; } // area_description

        // Navigasjon: Blokker tilknyttet området
        public ICollection<ContractorAreaBlock> ContractorAreaBlocks { get; set; }
    }
}
