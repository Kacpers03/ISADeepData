using System;

namespace DTOs.Qualifier_Dto
{
    public class QualifierDto
    {
        public int QualifierId { get; set; }
        public string QualifierCode { get; set; }
        public string QualifierDefinition { get; set; }
    }
}
