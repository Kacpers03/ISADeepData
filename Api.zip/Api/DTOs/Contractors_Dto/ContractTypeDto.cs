using System;

namespace  DTOs.Contractors_Dto
{
    public class ContractTypeDto
    {
        public int ContractTypeId { get; set; }
        public string ContractTypeName { get; set; }
    }
}
