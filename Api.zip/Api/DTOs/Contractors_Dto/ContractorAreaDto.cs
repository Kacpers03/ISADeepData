using System;

namespace  DTOs.Contractors_Dto
{
    public class ContractorAreaDto
    {
        public int AreaId { get; set; }
        public int ContractorId { get; set; }
        public string AreaName { get; set; }
        public string AreaDescription { get; set; }
    }
}
