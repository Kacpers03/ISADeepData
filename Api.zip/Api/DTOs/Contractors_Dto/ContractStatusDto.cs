using System;

namespace  DTOs.Contractors_Dto
{
    public class ContractStatusDto
    {
        public int ContractStatusId { get; set; }
        public string ContractStatusName { get; set; }
    }
}
