namespace Api.DTOs.Contractor
{
    public class ContractorAreaBlockDto
    {
        public int BlockId { get; set; }
        public int AreaId { get; set; }
        public string BlockName { get; set; }
        public string BlockDescription { get; set; }
        public string Status { get; set; }
    }
}
