namespace Api.DTOs.Contractor
{
    public class ContractStatusDto
    {
        public int ContractStatusId { get; set; }
        public string ContractStatusName { get; set; }
    }
}
